#include "UTrelloInterface.hpp"
#include <stdexcept>
#include <string>

#define CATCH_CONFIG_MAIN
#include "./Catch2-master/single_include/catch2/catch.hpp"

using namespace std;

TEST_CASE("Testing PrintTotalEstimatedTime function") {
	UTrelloInterface interface;
	interface.addUser("Sample_User1");
	interface.addUser("Sample_User2");
	interface.addUser("Sample_User3");
	interface.addUser("Sample_User4");
	interface.addUser("Sample_User5");
	interface.addUser("Sample_User6");
	interface.addList("Sample_List1");
	interface.addList("Sample_List2");
	interface.addList("Sample_List3");
	interface.addList("Sample_List4");
	interface.addTask("Sample_List1", "Sample_Task1", 10, 1, "Sample_Description1");
	interface.addTask("Sample_List1", "Sample_Task2", 11, 3, "Sample_Description2");
	interface.addTask("Sample_List2", "Sample_Task3", 9, 1, "Sample_Description3");
	interface.addTask("Sample_List2", "Sample_Task4", 20, 4, "Sample_Description4");
	interface.addTask("Sample_List2", "Sample_Task5", 25, 2, "Sample_Description5");
	interface.addTask("Sample_List3", "Sample_Task6", 33, 5, "Sample_Description6");
	interface.assignTask("Sample_Task2", "Sample_User1");
	interface.assignTask("Sample_Task3", "Sample_User1");
	interface.assignTask("Sample_Task4", "Sample_User2");
	interface.assignTask("Sample_Task5", "Sample_User2");
	interface.assignTask("Sample_Task6", "Sample_User4");
	interface.completeTask("Sample_Task3");
	interface.completeTask("Sample_Task5");
	REQUIRE(interface.printTotalEstimatedTime() == 98);
	interface.completeTask("Sample_Task2");
	interface.assignTask("Sample_Task1", "Sample_User6");
	REQUIRE(interface.printTotalEstimatedTime() == 108);
	}

TEST_CASE("Testing PrintTotalRemainingTime function") {
	UTrelloInterface interface;
	interface.addUser("Sample_User1");
	interface.addUser("Sample_User2");
	interface.addUser("Sample_User3");
	interface.addUser("Sample_User4");
	interface.addUser("Sample_User5");
	interface.addUser("Sample_User6");
	interface.addList("Sample_List1");
	interface.addList("Sample_List2");
	interface.addList("Sample_List3");
	interface.addList("Sample_List4");
	interface.addTask("Sample_List1", "Sample_Task1", 10, 1, "Sample_Description1");
	interface.addTask("Sample_List1", "Sample_Task2", 11, 3, "Sample_Description2");
	interface.addTask("Sample_List2", "Sample_Task3", 9, 1, "Sample_Description3");
	interface.addTask("Sample_List2", "Sample_Task4", 20, 4, "Sample_Description4");
	interface.addTask("Sample_List2", "Sample_Task5", 25, 2, "Sample_Description5");
	interface.addTask("Sample_List3", "Sample_Task6", 33, 5, "Sample_Description6");
	interface.assignTask("Sample_Task2", "Sample_User1");
	interface.assignTask("Sample_Task3", "Sample_User1");
	interface.assignTask("Sample_Task4", "Sample_User2");
	interface.assignTask("Sample_Task5", "Sample_User2");
	interface.assignTask("Sample_Task6", "Sample_User4");
	interface.completeTask("Sample_Task3");
	interface.completeTask("Sample_Task5");
	REQUIRE(interface.printTotalRemainingTime() == 64);
	REQUIRE(interface.printUserWorkload("Sample_User1") == 20);
	REQUIRE(interface.printUserWorkload("Sample_User2") == 45);
	REQUIRE(interface.printUserWorkload("Sample_User3") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User4") == 33);
	REQUIRE(interface.printUserWorkload("Sample_User5") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User6") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User7") == 0);
	interface.completeTask("Sample_Task2");
	REQUIRE(interface.printTotalRemainingTime() == 53);
	}

TEST_CASE("Testing printUserWorkload function") {
	UTrelloInterface interface;
	interface.addUser("Sample_User1");
	interface.addUser("Sample_User2");
	interface.addUser("Sample_User3");
	interface.addUser("Sample_User4");
	interface.addUser("Sample_User5");
	interface.addUser("Sample_User6");
	interface.addList("Sample_List1");
	interface.addList("Sample_List2");
	interface.addList("Sample_List3");
	interface.addList("Sample_List4");
	interface.addTask("Sample_List1", "Sample_Task1", 10, 1, "Sample_Description1");
	interface.addTask("Sample_List1", "Sample_Task2", 11, 3, "Sample_Description2");
	interface.addTask("Sample_List2", "Sample_Task3", 9, 1, "Sample_Description3");
	interface.addTask("Sample_List2", "Sample_Task4", 20, 4, "Sample_Description4");
	interface.addTask("Sample_List2", "Sample_Task5", 25, 2, "Sample_Description5");
	interface.addTask("Sample_List3", "Sample_Task6", 33, 5, "Sample_Description6");
	interface.assignTask("Sample_Task2", "Sample_User1");
	interface.assignTask("Sample_Task3", "Sample_User1");
	interface.assignTask("Sample_Task4", "Sample_User2");
	interface.assignTask("Sample_Task5", "Sample_User2");
	interface.assignTask("Sample_Task6", "Sample_User4");
	interface.completeTask("Sample_Task3");
	interface.completeTask("Sample_Task5");
	REQUIRE(interface.printUserWorkload("Sample_User1") == 20);
	REQUIRE(interface.printUserWorkload("Sample_User2") == 45);
	REQUIRE(interface.printUserWorkload("Sample_User3") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User4") == 33);
	REQUIRE(interface.printUserWorkload("Sample_User5") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User6") == 0);
	REQUIRE(interface.printUserWorkload("Sample_User7") == 0);
	interface.assignTask("Sample_Task1", "Sample_User6");
	REQUIRE(interface.printUserWorkload("Sample_User6") == 10);
	}